radicaciones = []
revisiones = []